import java.util.ArrayList;

public class InventoryManager implements ItemActions {
    private ArrayList<InventoryItem> items;

    public InventoryManager() {
        items = new ArrayList<>();
    }

    public void addItem(InventoryItem item) {
        items.add(item);
    }

    public void updateItem(int itemId, InventoryItem newItem) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).itemId == itemId) {
                items.set(i, newItem);
                break;
            }
        }
    }

    public void deleteItem(int itemId) {
        items.removeIf(item -> item.itemId == itemId);
    }

    public InventoryItem getItemDetails(int itemId) {
        for (InventoryItem item : items) {
            if (item.itemId == itemId) {
                return item;
            }
        }
        return null;
    }

    public void listAllItems() {
        for (InventoryItem item : items) {
            System.out.println(item);
        }
    }
}
