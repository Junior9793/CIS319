public interface ItemActions {
    void addItem(InventoryItem item);

    void updateItem(int itemId, InventoryItem newItem);

    void deleteItem(int itemId);

    InventoryItem getItemDetails(int itemId);
}
