public class Monitor extends InventoryItem {
    private String resolution;
    private int size;

    public Monitor(int itemId, String name, String category, double price, String resolution, int size) {
        super(itemId, name, category, price);
        this.resolution = resolution;
        this.size = size;
    }

    @Override
    public String getItemDescription() {
        return "Monitor - Resolution: " + resolution + ", Size: " + size + " inches";
    }

    @Override
    public String toString() {
        return super.toString() + ", " + getItemDescription();
    }
}
