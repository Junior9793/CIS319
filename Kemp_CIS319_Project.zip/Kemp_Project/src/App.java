public class App {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        // Sample usage of the inventory management system
        Laptop laptop = new Laptop(1, "Dell XPS 13", "Laptop", 1200.00, "Intel i7", 16, 512);
        Monitor monitor = new Monitor(2, "Samsung UltraWide", "Monitor", 600.00, "3440x1440", 34);

        manager.addItem(laptop);
        manager.addItem(monitor);

        manager.listAllItems();
    }
}
