public class Laptop extends InventoryItem {
    private String processor;
    private int ram;
    private int storage;

    public Laptop(int itemId, String name, String category, double price, String processor, int ram, int storage) {
        super(itemId, name, category, price);
        this.processor = processor;
        this.ram = ram;
        this.storage = storage;
    }

    @Override
    public String getItemDescription() {
        return "Laptop - Processor: " + processor + ", RAM: " + ram + "GB, Storage: " + storage + "GB";
    }

    @Override
    public String toString() {
        return super.toString() + ", " + getItemDescription();
    }
}
