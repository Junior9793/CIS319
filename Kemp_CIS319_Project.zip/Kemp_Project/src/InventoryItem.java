public abstract class InventoryItem {
    protected int itemId;
    protected String name;
    protected String category;
    protected double price;

    public InventoryItem(int itemId, String name, String category, double price) {
        this.itemId = itemId;
        this.name = name;
        this.category = category;
        this.price = price;
    }

    public abstract String getItemDescription();

    @Override
    public String toString() {
        return "ID: " + itemId + ", Name: " + name + ", Category: " + category + ", Price: $" + price;
    }
}
